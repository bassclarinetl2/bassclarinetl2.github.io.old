#!/bin/sh
##obs-unix-agent.sh
sudo su

apt install xinetd snmpd
cp observium_agent_xinetd /etc/xinetd.d/observium_xinetd
service xinetd restart

cp observium_agent /usr/bin/observium_agent

mkdir -p /usr/lib/observium_agent
mkdir -p /usr/lib/observium_agent/scripts-available
mkdir -p /usr/lib/observium_agent/scripts-enabled

cp agent-local/* /usr/lib/observium_agent/scripts-available

ln -s /usr/lib/observium_agent/scripts-available/os /usr/lib/observium_agent/scripts-enabled
ln -s /usr/lib/observium_agent/scripts-available/apache /usr/lib/observium_agent/scripts-enabled
ln -s /usr/lib/observium_agent/scripts-available/dmi /usr/lib/observium_agent/scripts-enabled
ln -s /usr/lib/observium_agent/scripts-available/dpkg /usr/lib/observium_agent/scripts-enabled
ln -s /usr/lib/observium_agent/scripts-available/lmsensors /usr/lib/observium_agent/scripts-enabled

exit 0